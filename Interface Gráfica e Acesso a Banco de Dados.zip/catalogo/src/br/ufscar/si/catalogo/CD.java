//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;

//Declara��o da classe CD que gerencia os objetos deste tipo
public class CD extends M�dia{

	//Declara��o dos atributos privados da classe CD
	private String artista;
	private String[] faixa;
	private int[] dura��o;
	private int faixas;
	
	//Declara��o do Construtor e dos m�todos da Classe
	public CD(String t�tulo, int anoCria��o, String artista){
	
		//IMPORTANTE - chamando o construtor da classe abstrata enviando os valores recebidos t�tulo e anoCria��o
		super(t�tulo, anoCria��o);
		this.artista = artista;
		this.faixa = new String[15];
		this.dura��o = new int[15];
		
		//Inicializando a vari�vel local tamanho para controlar a inser��o de faixas e dura��es
		faixas=0;
	}
	
	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfo(String info){
		this.artista = info;
	}
	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfos1(String[] info){this.faixa = info;}
	
	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfos2(String[] info){
		for(int i=0;i<info.length;i++)
			this.dura��o[i] = Integer.parseInt(info[i]);
	}
	
	//M�todo para retornar os dados das informa��es
	public String[] getInfos1(){return this.faixa;}
	
	//M�todo para retornar os dados das informa��es
	public String[] getInfos2(){
		String[] st = new String[15];
		for(int i=0;i<dura��o.length;i++)
			st[i] = String.valueOf(dura��o[i]);
		return st;
	}
	
	//M�todo para adicionar uma nova faixa - limite de 15
	public void adicionaFaixa(String faixa, int dura��o){
		if (faixas < 14){
			this.faixa[faixas] = faixa;
			this.dura��o[faixas] = dura��o;
			faixas++;
		}
	}
	
	//M�todo para retornar o tipo da m�dia
	public int getTipo(){
		return 1;
	}
	
	//M�todo para retornar os dados de m�dia como uma string formatada para JTextBox
	public String imprimeFicha(){
		
		String retorno = "\n\n"+"T�tulo: "+this.getT�tulo()+"\n"+"Ano: "+this.getAno()+"\n"+"Tipo: CD de M�sica"+"\n"+"Artista: "+this.artista+"\n\n";
    	for (int i=0; i<faixas; i++){
    		int minutos, segundos;
    		segundos = this.dura��o[i]%60;
    		minutos = this.dura��o[i]/60;
    		String duracaoFormatada = String.format("%02d:%02d", minutos, segundos);
    		retorno = retorno + "Faixa "+(i+1)+": "+this.faixa[i]+" - Dura��o: "+duracaoFormatada+"\n";
    	}
    	retorno = retorno +"\n";
    	return retorno;
	}
}
