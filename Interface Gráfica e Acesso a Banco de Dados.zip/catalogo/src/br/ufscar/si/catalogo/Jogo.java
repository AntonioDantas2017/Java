//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;

//Declara��o da classe Jogo que gerencia os objetos deste tipo
public class Jogo extends M�dia {

	//Declara��o dos atributos privados da classe Jogo
	private String g�nero;
	
	//Declara��o dos atributos privados da classe Jogo
	public Jogo(String t�tulo, int anoCria��o, String g�nero){
	
		//IMPORTANTE - chamando o construtor da classe abstrata enviando os valores recebidos t�tulo e anoCria��o
		super(t�tulo, anoCria��o);
		this.g�nero = g�nero;
	}
	
	//M�todo para retornar o tipo de m�dia
	public int getTipo(){
		return 3;
	}
	
	//M�todo para retornar os dados de m�dia como uma string formatada para JTextBox
	public String imprimeFicha(){	
		String retorno = "\n\n"+"T�tulo: "+this.getT�tulo()+"\n"+"Ano: "+this.getAno()+"\n"+"Tipo: Jogo"+"\n"+"G�nero: "+this.g�nero+"\n\n";
		return retorno;
	}

	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfo(String info){
		this.g�nero = info;
	}

	//Alterar informa��o do atributo por meio de um m�todo 
	//Por n�o ter info adicionais n�o foi necess�rio implementar
	public void setInfos1(String[] info){}
	public void setInfos2(String[] info){}
	
	//M�todo para retornar os dados das informa��es
	//Por n�o ter info adicionais n�o foi necess�rio implementar
	public String[] getInfos1(){return null;}
	public String[] getInfos2(){return null;}
}
