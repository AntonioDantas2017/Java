//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;

//Declara��o da classe DVD que gerencia os objetos deste tipo
public class DVD extends M�dia {

	//Declara��o dos atributos privados da classe DVD
	private String diretor;
	private String[] artista;
	private String[] papel;
	private int atores;
	
	//Declara��o do Construtor e dos m�todos da Classe
	public DVD(String t�tulo, int anoCria��o, String diretor){
	
		//IMPORTANTE - chamando o construtor da classe abstrata enviando os valores recebidos t�tulo e anoCria��o
		super(t�tulo, anoCria��o);
		this.diretor = diretor;
		this.artista = new String[5];
		this.papel = new String[5];
		
		//Inicializando a vari�vel local atores para controlar a inser��o de artistas e pap�is
		atores=0;
	}
	
	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfo(String info){
		this.diretor = info;
	}
	
	//Adiciona ao atributo mais artistas e papeis
	public void adicionaArtista(String artista, String papel){
		if (atores < 5){
			this.artista[atores] = artista;
			this.papel[atores] = papel;
			atores++;
		}
	}
	
	//M�todo para retornar o tipo de m�dia
	public int getTipo(){
		return 2;
	}
	
	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfos1(String[] info){this.papel = info;}
	
	//Alterar informa��o do atributo por meio de um m�todo
	public void setInfos2(String[] info){this.artista = info;}
	
	//M�todo para retornar os dados das informa��es
	public String[] getInfos1(){return this.artista;}
	
	//M�todo para retornar os dados das informa��es
	public String[] getInfos2(){return this.papel;}
	
	//M�todo para retornar os dados de m�dia como uma string formatada para JTextBox
	public String imprimeFicha(){
		
		String retorno = "\n\n"+"T�tulo: "+this.getT�tulo()+"\n"+"Ano: "+this.getAno()+"\n"+"Tipo: DVD de V�deo"+"\n"+"Diretor: "+this.diretor+"\n\n";
    	for (int i=0; i<atores; i++){
    		retorno = retorno + "Ator "+(i+1)+": "+this.artista[i]+" - Papel: "+this.papel[i]+"\n";
    	}
    	retorno = retorno +"\n";
    	return retorno;
	}
}
