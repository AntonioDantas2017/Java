//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;

//Declara��o da classe abstrata M�dia com seus atributos privados e seus m�todos abstratos
public abstract class M�dia {

	//Defini��o dos atributos privados da classe abstrata M�dia
	private String t�tulo;
	private int anoCria��o;
	
	//Declara��o do construtor e dos m�todos abstratos da classe
	public M�dia(String t�tulo, int anoCria��o){
		this.t�tulo = t�tulo;
		this.anoCria��o = anoCria��o;
	}
	
	//Declara��o dos m�todos a serem implementados nas classe
	public abstract int getTipo();
	public abstract void setInfo(String info);
	public abstract void setInfos1(String[] info);
	public abstract void setInfos2(String[] info);
	public abstract String[] getInfos1();
	public abstract String[] getInfos2();

	//M�todo para imprimir titulo
	public String imprimeFicha(){
		return t�tulo;
	}
	
	//M�todo para retornar titulo
	public String getT�tulo(){
		return this.t�tulo;
	}
	
	//M�todo para retornar ano
	public int getAno(){
		return this.anoCria��o;
	}
	
	//M�todo para alterar titulo
	public void setT�tulo(String titulo){
		this.t�tulo = titulo;
	}
	
	//M�todo para alterar o ano
	public void setAno(int ano){
		this.anoCria��o = ano;
	}
}
