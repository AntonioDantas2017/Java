//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;
//Importando bibliotecas necess�rias
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

//Declara��o da Classe Cat�logo que implementa a interface Cole��oM�dia
public class Cat�logo extends JFrame implements Cole��oM�dia, Serializable {
	
	//Declara��o dos atributos da classe Cat�logo
	private ArrayList<M�dia> m�dias;
	private int contador;
	private JButton btnImprimeColecao, btnOKCD;
	private JButton btnInclui, btnCancelar,btnAlteraCD,btnExcluiCD,btnConsultaCD;
	private static final long serialVersionUID = -1306760703066967345L;
	public static JLabel rotuloQtdMidias;
	public boolean tipoModifica��o;
	
	//Atributos do m�todo cadastraCD
	CD cd;
	DVD dvd;
	Jogo jogo;
	String tituloCD, artistaCD, tituloFaixa, tituloDVD, diretorDVD, nomeArtista, papelArtista, tituloJogo, generoJogo;
	int anoCD, anoDVD, anoJogo, dura��oFaixa, numfaixas=0, cadastraFaixas=1;
	JTextField inputTitulo, inputArtista, inputAno;
	JTextArea display;
    JScrollPane scroll;
	conectaBD bd;
	
	//Declara��o do construtor e dos m�todos da classe Cat�logo
	protected Cat�logo(){
		contador = 0;
		//Rotina para inicializar o array do cat�logo
		m�dias = new ArrayList<M�dia>();		
	}
	
	//M�todo para retornar o �timo item cadastrado
	public int ultimaPosicao(){
		conectaBD b = new conectaBD();
		if(b.conecta()){
			ResultSet rs = b.ler("select * from midia");
			try {
				rs.last();				
				return rs.getInt("ID");
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 1;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 1;
			}
		}else
			return 1;
	}
	
	//***********************************************************************************
	//    M�TODO PARA INICIALIZAR A JANELA GR�FICA - ADICIONA CD
	//***********************************************************************************	
    private void cadastraCD(final Cat�logo cat�logo, final JFrame principal) {
    	//Cabe�alho da tela
    	final JFrame cadastraCD = new JFrame();
    	cadastraCD.setTitle("SISTEMA DE ACERVO DE M�DIAS - CADASTRO DE CDs");
    	cadastraCD.setLayout(new GridLayout(0,1));
    	cadastraCD.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	
    	//definindo atributos locais
        //Iniciando r�tulos da p�gina
        JLabel rotulo1 = new JLabel("Cadastro de CDs - Preencha os campos abaixo:",JLabel.CENTER);
        JLabel rotuloTitulo = new JLabel("TITULO DO CD",JLabel.CENTER);
        JLabel rotuloArtista = new JLabel("ARTISTA DO CD",JLabel.CENTER);
        JLabel rotuloAno = new JLabel("ANO DO CD",JLabel.CENTER);
        JLabel rotuloBranco = new JLabel(" ",JLabel.CENTER);
        JLabel rotuloBranco2 = new JLabel("� ",JLabel.CENTER);
        
        //Iniciando areas de entrada de texto
        inputTitulo = new JTextField(30);
        inputTitulo.setHorizontalAlignment(JTextField.CENTER);
        inputArtista = new JTextField(50);
        inputArtista.setHorizontalAlignment(JTextField.CENTER);
        inputAno = new JTextField(4);
        inputAno.setHorizontalAlignment(JTextField.CENTER);
        
        //Iniciando Bot�es
        //BOT�O INCLUIR
        btnInclui = new JButton("Incluir CD");
        btnInclui.setLocation(100, 100);
        btnInclui.setVisible(true);
        btnInclui.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnInclui.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				tituloCD = inputTitulo.getText();
				artistaCD = inputArtista.getText();
				anoCD = Integer.parseInt(inputAno.getText());
				cd = new CD(tituloCD,anoCD,artistaCD);				
				cat�logo.bd.modificar("insert into midia (titulo,ano,tipo,info) values ('"+tituloCD+"',"+anoCD+",1,'"+artistaCD+"')");
				int id = cat�logo.ultimaPosicao();
				
				//Rotina para adicionar as faixas do CD
    	    	do{
    	    		tituloFaixa = JOptionPane.showInputDialog(" T�TULO DA FAIXA: ");
    	    		dura��oFaixa = Integer.parseInt(JOptionPane.showInputDialog(" DURA��O DA FAIXA: (em segundos) "));
    	    		
    	    		//chamando m�teodo para inserir faixas
    	    		cd.adicionaFaixa(tituloFaixa, dura��oFaixa);
    	    		numfaixas++;
    	    		cat�logo.bd.modificar("insert into lista (info,info2,midia_id) values ('"+tituloFaixa+"','"+dura��oFaixa+"',"+id+")");
        	        int resposta = JOptionPane.showConfirmDialog(null, "Cadastra mais faixas?", "CONFIRME PARA CONTINUAR", JOptionPane.YES_NO_OPTION);
        	        if (resposta == JOptionPane.NO_OPTION)
        	        {
        	          cadastraFaixas=0;
        	        }
        	        if (numfaixas == 15){
        	        	cadastraFaixas=0;
        	        	JOptionPane.showMessageDialog(null, "M�XIMO DE 15 FAIXAS CADASTRADAS - SAINDO...");
        	        }
    	    	}while(cadastraFaixas==1);
				
				if (cat�logo.adicionaM�dia(cd)){
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO CD FOI CADASTRADA COM SUCESSO");
					Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
					cadastraCD.setVisible(false);
					principal.setVisible(true);
				}
				else{
					JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO DA M�DIA");
					cadastraCD.setVisible(false);
					principal.setVisible(true);
				}
			}
		});
        
        //BOT�O CANCELAR
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setLocation(100, 100);
        btnCancelar.setVisible(true);
        btnCancelar.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnCancelar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cadastraCD.setVisible(false);
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				principal.setVisible(true);
				
			}
		});
        
        //BOT�O EXCLUIR
        btnExcluiCD = new JButton("Exclui CD");
        btnExcluiCD.setLocation(100, 100);
        btnExcluiCD.setVisible(true);
        btnExcluiCD.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnExcluiCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 1");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						tipoModifica��o = false;
						btnOKCD.setVisible(true);
						
						inputTitulo.setEnabled(false);
						inputArtista.setEnabled(false);
						inputAno.setEnabled(false);

						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O CD");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O CONSULTA
        btnConsultaCD = new JButton("Consulta CD");
        btnConsultaCD.setLocation(100, 100);
        btnConsultaCD.setVisible(true);
        btnConsultaCD.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnConsultaCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 1");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						inputTitulo.setEnabled(false);
						inputArtista.setEnabled(false);
						inputAno.setEnabled(false);
						int id = rs.getInt("id");
						
						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
						
						rs = cat�logo.bd.ler("select * from lista where midia_id = "+id+"");
						while(rs.next()){
							System.out.println("Artista: "+rs.getString("info")+"\n Papel:"+rs.getString("info2"));
							JOptionPane.showMessageDialog(null, "Faixa: "+rs.getString("info")+"\n Dura��o(seg):"+rs.getString("info2"));
						}
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O CD");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O ALTERAR
        btnAlteraCD = new JButton("Altera CD");
        btnAlteraCD.setLocation(100, 100);
        btnAlteraCD.setVisible(true);
        btnAlteraCD.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnAlteraCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 1");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						tipoModifica��o = true;
						btnOKCD.setVisible(true);
						inputTitulo.setEnabled(false);
						
						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O CD");
					}
				} catch (NumberFormatException e) {
				} catch (SQLException e) {
				}
			}
		});
        
        //BOT�O OK
        btnOKCD = new JButton("OK");
        btnOKCD.setLocation(100, 100);
        btnOKCD.setVisible(false);
        btnOKCD.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnOKCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				tituloCD = inputTitulo.getText();
				artistaCD = inputArtista.getText();
				anoCD = Integer.parseInt(inputAno.getText());
				if(tipoModifica��o){
					
					int pos = 0;
					
					for (int i=0; i<m�dias.size(); i++){
						if (tituloCD.equals(m�dias.get(i).getT�tulo())){
							pos = i;
							m�dias.get(i).setAno(anoCD);
							m�dias.get(i).setInfo(artistaCD);
						}
					}					
					
					cat�logo.bd.modificar("update midia set ano="+anoCD+",info='"+artistaCD+"' where titulo = '"+tituloCD+"' and tipo = 1");
					
					ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+tituloCD+"' and tipo = 1");
					int id = 0;
					try {
						if(rs.next()){				
							id = rs.getInt("id");
							System.out.println(id);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					String[] auxA = new String[15];
					String[] auxP = new String[15]; 
					auxA = m�dias.get(pos).getInfos1();
					auxP = m�dias.get(pos).getInfos2();
					
					for (int i=0; i<auxA.length; i++){
						if (!auxA[i].equals("")){
							String aux = JOptionPane.showInputDialog("Faixa "+auxA[i]);
							String aux2 = JOptionPane.showInputDialog("Dura��o(seg) "+auxP[i]);
							
							if(!aux.equals("")){
								System.out.println(aux+" "+aux2+"="+auxA[i]+" "+auxP[i]);
								cat�logo.bd.modificar("update lista set info='"+aux+"' where midia_id= "+id+" and info='"+auxA[i]+"'");
								auxA[i] = aux;
							}
							if(!aux2.equals("")){
								cat�logo.bd.modificar("update lista set info2='"+aux2+"' where midia_id= "+id+"  and info2='"+auxP[i]+"'");
								auxP[i] = aux2;
							}
							
						}
					}
					m�dias.get(pos).setInfos1(auxA);
					m�dias.get(pos).setInfos2(auxP);
					
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO CD FOI ALTERADA COM SUCESSO");
				}else{
					for (int i=0; i<m�dias.size(); i++){
						if (tituloCD.equals(m�dias.get(i).getT�tulo())){
							m�dias.remove(i);
						}
					}					
					ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+tituloCD+"' and tipo = 1");
					int id = 0;
					try {
						if(rs.next()){				
							id = rs.getInt("id");
							System.out.println(id);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					cat�logo.bd.modificar("delete from lista where midia_id = "+id+"");
					cat�logo.bd.modificar("delete from midia where id = "+id+"");
				
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO CD FOI EXCLUIDA COM SUCESSO");
				}
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				cadastraCD.setVisible(false);
				principal.setVisible(true);		
			}
		});
        
        //Mostrando a janela de cadastro de CD
        cadastraCD.add(rotulo1);
        cadastraCD.add(rotuloTitulo);
        cadastraCD.add(inputTitulo);
        cadastraCD.add(rotuloArtista);
        cadastraCD.add(inputArtista);
        cadastraCD.add(rotuloAno);
        cadastraCD.add(inputAno);
        cadastraCD.add(rotuloBranco);
        cadastraCD.add(rotuloBranco2);
        cadastraCD.add(btnInclui);
        cadastraCD.add(btnExcluiCD);
        cadastraCD.add(btnAlteraCD);
        cadastraCD.add(btnConsultaCD);
        cadastraCD.add(btnOKCD);
        cadastraCD.add(rotuloBranco);
        cadastraCD.add(btnCancelar);
        cadastraCD.add(rotuloBranco);
        cadastraCD.pack();
        cadastraCD.setLocation(200, 200);
        cadastraCD.setSize(800, 600);
        cadastraCD.setVisible(true);
    }
	
	//***********************************************************************************
	//    M�TODO PARA INICIALIZAR A JANELA GR�FICA - ADICIONA DVD
	//***********************************************************************************	
    private void cadastraDVD(final Cat�logo cat�logo, final JFrame principal) {
    	//Cabe�alho da tela
    	final JFrame cadastraDVD = new JFrame();
    	cadastraDVD.setTitle("SISTEMA DE ACERVO DE M�DIAS - CADASTRO DE DVDs");
    	cadastraDVD.setLayout(new GridLayout(0,1));
    	cadastraDVD.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	
    	//definindo atributos locais
        //Iniciando r�tulos da p�gina
        JLabel rotulo1 = new JLabel("Cadastro de DVDs - Preencha os campos abaixo:",JLabel.CENTER);
        JLabel rotuloTitulo = new JLabel("TITULO DO FILME",JLabel.CENTER);
        JLabel rotuloArtista = new JLabel("DIRETOR DO FILME",JLabel.CENTER);
        JLabel rotuloAno = new JLabel("ANO DO FILME",JLabel.CENTER);
        JLabel rotuloBranco = new JLabel(" ",JLabel.CENTER);
        JLabel rotuloBranco2 = new JLabel("� ",JLabel.CENTER);

        //Iniciando areas de entrada de texto
        inputTitulo = new JTextField(30);
        inputTitulo.setHorizontalAlignment(JTextField.CENTER);
        inputArtista = new JTextField(50);
        inputArtista.setHorizontalAlignment(JTextField.CENTER);
        inputAno = new JTextField(4);
        inputAno.setHorizontalAlignment(JTextField.CENTER);
        
        //Iniciando Bot�es
        //BOT�O INCLUIR
        btnInclui = new JButton("Incluir DVD");
        btnInclui.setLocation(100, 100);
        btnInclui.setVisible(true);
        btnInclui.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnInclui.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				tituloDVD = inputTitulo.getText();
				diretorDVD = inputArtista.getText();
				anoDVD = Integer.parseInt(inputAno.getText());
				//System.out.println(tituloCD + artistaCD + anoCD);
				dvd = new DVD(tituloDVD,anoDVD,diretorDVD);
				cat�logo.bd.modificar("insert into midia (titulo,ano,tipo,info) values ('"+tituloDVD+"',"+anoDVD+",2,'"+diretorDVD+"')");
				int id = cat�logo.ultimaPosicao();
				
				//Rotina para adicionar os artistas do DVD
    	    	do{
    	    		nomeArtista = JOptionPane.showInputDialog(" NOME ARTISTA: ");
    	    		papelArtista = JOptionPane.showInputDialog(" PAPEL NO FILME ");
    	    		dvd.adicionaArtista(nomeArtista, papelArtista);
    				cat�logo.bd.modificar("insert into lista (info,info2,midia_id) values ('"+nomeArtista+"','"+papelArtista+"',"+id+")");    	    		
    	    		numfaixas++;
        	        int resposta = JOptionPane.showConfirmDialog(null, "Cadastra mais artistas?", "CONFIRME PARA CONTINUAR", JOptionPane.YES_NO_OPTION);
        	        if (resposta == JOptionPane.NO_OPTION)
        	        {
        	          cadastraFaixas=0;
        	        }
        	        if (numfaixas == 15){
        	        	cadastraFaixas=0;
        	        	JOptionPane.showMessageDialog(null, "M�XIMO DE 15 ARTISTAS CADASTRADOS - SAINDO...");
        	        }
    	    	}while(cadastraFaixas==1);
				
				if (cat�logo.adicionaM�dia(dvd)){
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO DVD FOI CADASTRADA COM SUCESSO");
					Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
					cadastraDVD.setVisible(false);
					principal.setVisible(true);
				}
				else{
					JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO DA M�DIA");
					cadastraDVD.setVisible(false);
					principal.setVisible(true);
				}
			}
		});
        
        //BOT�O CANCELAR
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setLocation(100, 100);
        btnCancelar.setVisible(true);
        btnCancelar.setBounds(100, 100, 100, 30);
        btnCancelar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cadastraDVD.setVisible(false);
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				principal.setVisible(true);
				
			}
		});
        
        //BOT�O EXCLUIR
        btnExcluiCD = new JButton("Exclui DVD");
        btnExcluiCD.setLocation(100, 100);
        btnExcluiCD.setVisible(true);
        btnExcluiCD.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnExcluiCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 2");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						tipoModifica��o = false;
						btnOKCD.setVisible(true);
						
						inputTitulo.setEnabled(false);
						inputArtista.setEnabled(false);
						inputAno.setEnabled(false);

						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O JOGO");
					}
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O CONSULTA
        btnConsultaCD = new JButton("Consulta DVD");
        btnConsultaCD.setLocation(100, 100);
        btnConsultaCD.setVisible(true);
        btnConsultaCD.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnConsultaCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 2");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						inputTitulo.setEnabled(false);
						inputArtista.setEnabled(false);
						inputAno.setEnabled(false);
						int id = rs.getInt("id");
						
						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
						
						rs = cat�logo.bd.ler("select * from lista where midia_id = "+id+"");
						while(rs.next()){
							System.out.println("Artista: "+rs.getString("info")+"\n Papel:"+rs.getString("info2"));
							JOptionPane.showMessageDialog(null, "Artista: "+rs.getString("info")+"\n Papel:"+rs.getString("info2"));
						}
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O DVD");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O ALTERAR
        btnAlteraCD = new JButton("Altera DVD");
        btnAlteraCD.setLocation(100, 100);
        btnAlteraCD.setVisible(true);
        btnAlteraCD.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnAlteraCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 2");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						tipoModifica��o = true;
						btnOKCD.setVisible(true);
						inputTitulo.setEnabled(false);
						
						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O DVD");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
      //BOT�O OK
        btnOKCD = new JButton("OK");
        btnOKCD.setLocation(100, 100);
        btnOKCD.setVisible(false);
        btnOKCD.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnOKCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				tituloDVD = inputTitulo.getText();
				diretorDVD = inputArtista.getText();
				anoDVD = Integer.parseInt(inputAno.getText());
				
				if(tipoModifica��o){
					
					int pos = 0;
					
					for (int i=0; i<m�dias.size(); i++){
						if (tituloDVD.equals(m�dias.get(i).getT�tulo())){
							//m�dias.get(i).setT�tulo(tituloJogo);
							pos = i;
							m�dias.get(i).setAno(anoDVD);
							m�dias.get(i).setInfo(diretorDVD);
						}
					}					
					
					cat�logo.bd.modificar("update midia set ano="+anoDVD+",info='"+diretorDVD+"' where titulo = '"+tituloDVD+"' and tipo = 2");
					
					ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+tituloDVD+"' and tipo = 2");
					int id = 0;
					try {
						if(rs.next()){				
							id = rs.getInt("id");
							System.out.println(id);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					String[] auxA = new String[15];
					String[] auxP = new String[15]; 
					auxA = m�dias.get(pos).getInfos1();
					auxP = m�dias.get(pos).getInfos2();
					
					for (int i=0; i<auxA.length; i++){
						if (!auxA[i].equals("")){
							String aux = JOptionPane.showInputDialog("Artista "+auxA[i]);
							String aux2 = JOptionPane.showInputDialog("Papel "+auxP[i]);
							
							if(!aux.equals("")){
								System.out.println(aux+" "+aux2+"="+auxA[i]+" "+auxP[i]);
								cat�logo.bd.modificar("update lista set info='"+aux+"' where midia_id= "+id+" and info='"+auxA[i]+"'");
								auxA[i] = aux;
							}
							if(!aux2.equals("")){
								cat�logo.bd.modificar("update lista set info2='"+aux2+"' where midia_id= "+id+"  and info2='"+auxP[i]+"'");
								auxP[i] = aux2;
							}
							
						}
					}
					m�dias.get(pos).setInfos1(auxA);
					m�dias.get(pos).setInfos2(auxP);
					
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO DVD FOI ALTERADA COM SUCESSO");
				}else{
					for (int i=0; i<m�dias.size(); i++){
						if (tituloDVD.equals(m�dias.get(i).getT�tulo())){
							m�dias.remove(i);
						}
					}					
					ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+tituloDVD+"' and tipo = 2");
					int id = 0;
					try {
						if(rs.next()){				
							id = rs.getInt("id");
							System.out.println(id);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
					cat�logo.bd.modificar("delete from lista where midia_id = "+id+"");
					cat�logo.bd.modificar("delete from midia where id = "+id+"");
				
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO DVD FOI EXCLUIDA COM SUCESSO");
				}
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				cadastraDVD.setVisible(false);
				principal.setVisible(true);		
			}
		});
        
        //Mostrando a janela de cadastro de CD
        cadastraDVD.add(rotulo1);
        cadastraDVD.add(rotuloBranco);
        cadastraDVD.add(rotuloTitulo);
        cadastraDVD.add(inputTitulo);
        cadastraDVD.add(rotuloArtista);
        cadastraDVD.add(inputArtista);
        cadastraDVD.add(rotuloAno);
        cadastraDVD.add(inputAno);
        cadastraDVD.add(rotuloBranco);
        cadastraDVD.add(rotuloBranco2);
        cadastraDVD.add(btnInclui);
        cadastraDVD.add(btnAlteraCD);
        cadastraDVD.add(btnExcluiCD);
        cadastraDVD.add(btnConsultaCD);
        cadastraDVD.add(btnOKCD);
        cadastraDVD.add(rotuloBranco);
        cadastraDVD.add(btnCancelar);
        cadastraDVD.pack();
        cadastraDVD.setLocation(200, 200);
        cadastraDVD.setSize(800, 600);
        cadastraDVD.setVisible(true);
    }
	 
   
	//***********************************************************************************
	//    M�TODO PARA INICIALIZAR A JANELA GR�FICA - ADICIONA JOGO
	//***********************************************************************************	
    private void cadastraJogo(final Cat�logo cat�logo, final JFrame principal) {
    	//Cabe�alho da tela
    	final JFrame cadastraJogo = new JFrame();
    	cadastraJogo.setTitle("SISTEMA DE ACERVO DE M�DIAS - CADASTRO DE JOGOS");
    	cadastraJogo.setLayout(new GridLayout(0,1));
    	cadastraJogo.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	
    	//definindo atributos locais
        //Iniciando r�tulos da p�gina
        JLabel rotulo1 = new JLabel("Cadastro de Jogos - Preencha os campos abaixo:",JLabel.CENTER);
        JLabel rotuloTitulo = new JLabel("TITULO DO JOGO",JLabel.CENTER);
        JLabel rotuloArtista = new JLabel("GENERO DO JOGO",JLabel.CENTER);
        JLabel rotuloAno = new JLabel("ANO DO JOGO",JLabel.CENTER);
        JLabel rotuloBranco = new JLabel(" ",JLabel.CENTER);
        JLabel rotuloBranco2 = new JLabel("�� ",JLabel.CENTER);
        inputTitulo = new JTextField(30);
        inputTitulo.setHorizontalAlignment(JTextField.CENTER);
        inputArtista = new JTextField(50);
        inputArtista.setHorizontalAlignment(JTextField.CENTER);
        inputAno = new JTextField(4);
        inputAno.setHorizontalAlignment(JTextField.CENTER);
        
        //BOT�O INCLUIR
        btnInclui = new JButton("Incluir JOGO");
        btnInclui.setLocation(100, 100);
        btnInclui.setVisible(true);
        btnInclui.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnInclui.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				tituloJogo = inputTitulo.getText();
				generoJogo = inputArtista.getText();
				anoJogo = Integer.parseInt(inputAno.getText());
				jogo = new Jogo(tituloJogo,anoJogo,generoJogo);
				cat�logo.bd.modificar("insert into midia (titulo,ano,tipo,info) values ('"+tituloJogo+"',"+anoJogo+",3,'"+generoJogo+"')");				
			
				if (cat�logo.adicionaM�dia(jogo)){
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO JOGO FOI CADASTRADA COM SUCESSO");
					Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
					cadastraJogo.setVisible(false);
					principal.setVisible(true);
				}
				else{
					JOptionPane.showMessageDialog(null, "OCORREU UM PROBLEMA NO CADASTRO DA M�DIA");
					cadastraJogo.setVisible(false);
					principal.setVisible(true);
				}
			}
		});
        
        //BOT�O EXCLUIR
        btnExcluiCD = new JButton("Exclui Jogo");
        btnExcluiCD.setLocation(100, 100);
        btnExcluiCD.setVisible(true);
        btnExcluiCD.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnExcluiCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 3");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						tipoModifica��o = false;
						btnOKCD.setVisible(true);
						
						inputTitulo.setEnabled(false);
						inputArtista.setEnabled(false);
						inputAno.setEnabled(false);

						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O JOGO");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O EXCLUIR
        btnConsultaCD = new JButton("Consulta Jogo");
        btnConsultaCD.setLocation(100, 100);
        btnConsultaCD.setVisible(true);
        btnConsultaCD.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnConsultaCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 3");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						inputTitulo.setEnabled(false);
						inputArtista.setEnabled(false);
						inputAno.setEnabled(false);
						
						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O JOGO");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O ALTERAR
        btnAlteraCD = new JButton("Altera Jogo");
        btnAlteraCD.setLocation(100, 100);
        btnAlteraCD.setVisible(true);
        btnAlteraCD.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnAlteraCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				String busca = JOptionPane.showInputDialog(" T�tulo para busca: ");
				ResultSet rs = cat�logo.bd.ler("select * from midia where titulo = '"+busca+"' and tipo = 3");
				try {
					if(rs.next()){				
						inputTitulo.setText(rs.getString("titulo"));
						inputArtista.setText(rs.getString("info"));
						inputAno.setText(String.valueOf(rs.getInt("ano")));
						tipoModifica��o = true;
						btnOKCD.setVisible(true);
						inputTitulo.setEnabled(false);
						
						btnInclui.setVisible(false);
						btnExcluiCD.setVisible(false);
						btnConsultaCD.setVisible(false);
						btnAlteraCD.setVisible(false);
					}else{
						JOptionPane.showMessageDialog(null, "N�O FOI POSS�VEL ENCONTRAR O JOGO");
					}
				} catch (NumberFormatException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
        
        //BOT�O OK
        btnOKCD = new JButton("OK");
        btnOKCD.setLocation(100, 100);
        btnOKCD.setVisible(false);
        btnOKCD.setBounds(100, 100, 100, 30);

        //A��o de clique do usu�rio sendo sobrescrito
        btnOKCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				if(tipoModifica��o){
					tituloJogo = inputTitulo.getText();
					generoJogo = inputArtista.getText();
					anoJogo = Integer.parseInt(inputAno.getText());
					
					for (int i=0; i<m�dias.size(); i++){
						if (tituloJogo.equals(m�dias.get(i).getT�tulo())){
							//m�dias.get(i).setT�tulo(tituloJogo);
							m�dias.get(i).setAno(anoJogo);
							m�dias.get(i).setInfo(generoJogo);
						}
					}					
					
					cat�logo.bd.modificar("update midia set ano="+anoJogo+",info='"+generoJogo+"' where titulo = '"+tituloJogo+"' and tipo = 3");				
				
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO JOGO FOI ALTERADA COM SUCESSO");
				}else{
					for (int i=0; i<m�dias.size(); i++){
						if (tituloJogo.equals(m�dias.get(i).getT�tulo())){
							m�dias.remove(i);
						}
					}					
					cat�logo.bd.modificar("delete from midia where titulo = '"+tituloJogo+"' and tipo = 3");				
				
					JOptionPane.showMessageDialog(null, "A M�DIA DO TIPO JOGO FOI EXCLUIDA COM SUCESSO");
				}
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				cadastraJogo.setVisible(false);
				principal.setVisible(true);		
			}
		});
      
        //BOT�O CANCELAR
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setLocation(100, 100);
        btnCancelar.setVisible(true);
        btnCancelar.setBounds(100, 100, 100, 30);
        btnCancelar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cadastraJogo.setVisible(false);
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				principal.setVisible(true);
				
			}
		});
        
        //Mostrando a janela de cadastro de CD
        cadastraJogo.add(rotulo1);
        cadastraJogo.add(rotuloBranco);
        cadastraJogo.add(rotuloTitulo);
        cadastraJogo.add(inputTitulo);
        cadastraJogo.add(rotuloArtista);
        cadastraJogo.add(inputArtista);
        cadastraJogo.add(rotuloAno);
        cadastraJogo.add(inputAno);
        cadastraJogo.add(rotuloBranco);
        cadastraJogo.add(rotuloBranco2);
        cadastraJogo.add(btnInclui);
        cadastraJogo.add(btnAlteraCD);
        cadastraJogo.add(btnConsultaCD);
        cadastraJogo.add(btnExcluiCD);
        cadastraJogo.add(btnOKCD);
        cadastraJogo.add(rotuloBranco);
        cadastraJogo.add(btnCancelar);
        cadastraJogo.pack();
        cadastraJogo.setLocation(200, 200);
        cadastraJogo.setSize(800, 600);
        cadastraJogo.setVisible(true);
    }
    
	//***********************************************************************************
	//    M�TODO PARA INICIALIZAR A JANELA GR�FICA - IMPRIME COLE��O
	//***********************************************************************************	
    private void imprimeColecao(final Cat�logo cat�logo, final JFrame principal) {
    	//Cabe�alho da tela
    	final JFrame imprimeColecao = new JFrame();
    	imprimeColecao.setTitle("IMPRESS�O DA COLE��O");
    	imprimeColecao.setLayout(new FlowLayout());
    	imprimeColecao.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	
    	//definindo atributos locais
        //Iniciando r�tulos da p�gina
        final JLabel rotulo1 = new JLabel("   *** IMPRESS�O DA COLE��O - CLIQUE NO BOT�O PARA GERAR OS DADOS ***  ",JLabel.CENTER);
        final JLabel rotulo3 = new JLabel();
        JLabel rotuloBranco = new JLabel("\n",JLabel.CENTER);

        //Definindo Text Areas COM scroll
        display = new JTextArea(26, 58);
        display.setEditable(false); // bloqueia textarea para edi��o
        scroll = new JScrollPane(display);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        //BOT�O INCLUIR
        btnImprimeColecao = new JButton("Imprimir Cole��o");
        btnImprimeColecao.setLocation(100, 100);
        btnImprimeColecao.setVisible(true);
        btnImprimeColecao.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnImprimeColecao.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				
				// impress�o do cat�logo no elemento JTextArea
				display.setText(cat�logo.imprimeCole��o());
				display.setVisible(true);
			}
		});

        //BOT�O CANCELAR
        btnCancelar = new JButton("SAIR");
        btnCancelar.setLocation(100, 100);
        btnCancelar.setVisible(true);
        btnCancelar.setBounds(100, 100, 100, 30);
       
        //A��o de clique do usu�rio sendo sobrescrito
        btnCancelar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				imprimeColecao.setVisible(false);
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				principal.setVisible(true);
				
			}
		});
        
        //Mostrando a janela de impress�o de cole��o
        imprimeColecao.add(rotuloBranco);
        imprimeColecao.add(rotulo1);
        imprimeColecao.add(rotuloBranco);
        imprimeColecao.add(rotuloBranco);
        imprimeColecao.add(btnImprimeColecao);
        imprimeColecao.add(btnCancelar);
        imprimeColecao.add(rotuloBranco);
        imprimeColecao.add(rotuloBranco);
        imprimeColecao.add(scroll);
        imprimeColecao.add(rotuloBranco);
        imprimeColecao.add(rotulo3);
        imprimeColecao.pack();
        imprimeColecao.setLocation(200, 200);
        imprimeColecao.setSize(800, 600);
        imprimeColecao.setVisible(true);
    }

	//***********************************************************************************
	//    M�TODO PARA INICIALIZAR A JANELA GR�FICA - IMPRIME COLE��O POR TIPO
	//***********************************************************************************	
    private void imprimeColecaoTipo(final Cat�logo cat�logo, final JFrame principal) {
    	//Cabe�alho da tela
    	final JFrame imprimeColecaoTipo = new JFrame();
    	imprimeColecaoTipo.setTitle("IMPRESS�O DA COLE��O POR TIPO");
    	imprimeColecaoTipo.setLayout(new FlowLayout());
    	imprimeColecaoTipo.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	
    	//definindo atributos locais
        //Iniciando r�tulos da p�gina
        final JLabel rotulo1 = new JLabel("   *** IMPRESS�O DA COLE��O POR TIPO - CLIQUE NO BOT�O PARA GERAR OS DADOS ***  ",JLabel.CENTER);
        final JLabel rotulo3 = new JLabel();
        JLabel rotuloBranco = new JLabel("\n",JLabel.CENTER);
        
        //Definindo Text Areas COM scroll
        display = new JTextArea(26, 58);
        display.setEditable(false); // bloqueia textarea para edi��o
        scroll = new JScrollPane(display);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        //Iniciando Bot�es
        //BOT�O INCLUIR
        btnImprimeColecao = new JButton("Imprimir Cole��o por Tipo");
        btnImprimeColecao.setLocation(100, 100);
        btnImprimeColecao.setVisible(true);
        btnImprimeColecao.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnImprimeColecao.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				// impress�o do cat�logo no elemento JTextArea
				int tipo = Integer.parseInt(JOptionPane.showInputDialog("Digite o tipo da cole��o (1-CD  |  2-DVD  | 3-JOGO)"));
				display.setText(cat�logo.imprimeCole��oPorTipo(tipo));
				display.setVisible(true);
			}
		});
        
        //BOT�O CANCELAR
        btnCancelar = new JButton("SAIR");
        btnCancelar.setLocation(100, 100);
        btnCancelar.setVisible(true);
        btnCancelar.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnCancelar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				imprimeColecaoTipo.setVisible(false);
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				principal.setVisible(true);
				
			}
		});
        
        //Mostrando a janela de impress�o de cole��o
        imprimeColecaoTipo.add(rotuloBranco);
        imprimeColecaoTipo.add(rotulo1);
        imprimeColecaoTipo.add(rotuloBranco);
        imprimeColecaoTipo.add(rotuloBranco);
        imprimeColecaoTipo.add(btnImprimeColecao);
        imprimeColecaoTipo.add(btnCancelar);
        imprimeColecaoTipo.add(rotuloBranco);
        imprimeColecaoTipo.add(rotuloBranco);
        imprimeColecaoTipo.add(scroll);
        imprimeColecaoTipo.add(rotuloBranco);
        imprimeColecaoTipo.add(rotulo3);
        imprimeColecaoTipo.pack();
        imprimeColecaoTipo.setLocation(200, 200);
        imprimeColecaoTipo.setSize(800, 600);
        imprimeColecaoTipo.setVisible(true);
    }
    
    
	//***********************************************************************************
	//    M�TODO PARA INICIALIZAR A JANELA GR�FICA - IMPRIME BUSCA POR TITULO
	//***********************************************************************************	
    private void buscaPorTitulo(final Cat�logo cat�logo, final JFrame principal) {
    	//Cabe�alho da tela
    	final JFrame buscaPorTitulo = new JFrame();
    	buscaPorTitulo.setTitle("IMPRESS�O DA BUSCA POR T�TULO");
    	buscaPorTitulo.setLayout(new FlowLayout());
    	buscaPorTitulo.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    	
    	//definindo atributos locais
        //Iniciando r�tulos da p�gina
        final JLabel rotulo1 = new JLabel("   *** BUSCA POR T�TULO - CLIQUE NO BOT�O PARA BUSCAR ***  ",JLabel.CENTER);
        final JLabel rotulo3 = new JLabel();
        JLabel rotuloBranco = new JLabel("\n",JLabel.CENTER);
        
        //Definindo Text Areas COM scroll
        display = new JTextArea(26, 58);
        display.setEditable(false); // bloqueia textarea para edi��o
        scroll = new JScrollPane(display);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        
        //BOT�O INCLUIR
        btnImprimeColecao = new JButton("Buscar por T�tulo");
        btnImprimeColecao.setLocation(100, 100);
        btnImprimeColecao.setVisible(true);
        btnImprimeColecao.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnImprimeColecao.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent ae) {
				// impress�o do cat�logo no elemento JTextArea
				String busca = JOptionPane.showInputDialog("Digite o t�tulo para buscar");
				display.setText(cat�logo.imprimePorTitulo(busca));
				display.setVisible(true);
			}
		});
        
        //BOT�O CANCELAR
        btnCancelar = new JButton("SAIR");
        btnCancelar.setLocation(100, 100);
        btnCancelar.setVisible(true);
        btnCancelar.setBounds(100, 100, 100, 30);
        
        //A��o de clique do usu�rio sendo sobrescrito
        btnCancelar.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				buscaPorTitulo.setVisible(false);
				Cat�logo.rotuloQtdMidias.setText("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()));
				principal.setVisible(true);
				
			}
		});
        
        //Mostrando a janela de impress�o de cole��o
        buscaPorTitulo.add(rotuloBranco);
        buscaPorTitulo.add(rotulo1);
        buscaPorTitulo.add(rotuloBranco);
        buscaPorTitulo.add(rotuloBranco);
        buscaPorTitulo.add(btnImprimeColecao);
        buscaPorTitulo.add(btnCancelar);
        buscaPorTitulo.add(rotuloBranco);
        buscaPorTitulo.add(rotuloBranco);
        buscaPorTitulo.add(scroll);
        buscaPorTitulo.add(rotuloBranco);
        buscaPorTitulo.add(rotulo3);
        buscaPorTitulo.pack();
        buscaPorTitulo.setLocation(200, 200);
        buscaPorTitulo.setSize(800, 600);
        buscaPorTitulo.setVisible(true);
    }
    
   //******************************************************************************************
   //               FIM DO C�DIGO DAS JANELAS GR�FICAS
   //******************************************************************************************

    //Metodo para adicionar m�dia
	boolean adicionaM�dia(M�dia m�dia){
		if (m�dias.add(m�dia)){
			contador++;
			return true;
		}
		else{
			return false;
		}
	}
	
	//Metodo para retornar dados da m�dia pelo t�tulo
	public M�dia obtemM�dia(String t�tulo){
		for (int i=0; i<contador; i++){
			if (t�tulo.compareTo(m�dias.get(i).getT�tulo()) == 0){
				return m�dias.get(i);
			}
		}
		return null;
	}
	
	//Metodo para retornar quantidade m�xima de m�dias
	public int quantidadeM�ximaDeM�dias(){
		return m�dias.size();
	}
	
	//M�todo para retornar quantidade de m�dias cadastradas
	public int quantidadeDeM�dias(){
		return contador;
	}
	
	//M�todo para retornar quantidade de CDs cadastrados
	public int quantidadeDeCDs(){
		int totalCDs=0;
		for (int i=0; i<contador; i++){
			if (m�dias.get(i).getTipo()==1){
				totalCDs++;
			}
		}
		return totalCDs;
	}
	
	//M�todo para retornar quantidade de DVDs cadastrados
	public int quantidadeDeDVDs(){
		int totalDVDs=0;
		for (int j=0; j<contador; j++){
			if (m�dias.get(j).getTipo()==2){
				totalDVDs++;
			}
		}
		return totalDVDs;
	}
	
	//M�todo para retornar quantidade de Jogos cadastrados
	public int quantidadeDeJogos(){
		int totalJogos=0;
		for (int k=0; k<contador; k++){
			if (m�dias.get(k).getTipo()==3){
				totalJogos++;
			}
		}
		return totalJogos;
	}
	
	//Retorna o array da cole��o para o m�todo imprimeCole��o
	public ArrayList<M�dia> cole��o(){
		return m�dias;
		
	}
	
	//M�todo para imprimir cole��o
	public String imprimeCole��o(){
		String retorno = "    ******* IMPRESS�O DA COLE��O DE M�DIAS ******    ";
		for (int i=0; i<m�dias.size(); i++){
			retorno = retorno +"\n"+ m�dias.get(i).imprimeFicha();
		}
		return retorno;
	}
	
	//M�todo para imprimir busca por titulo
	public String imprimePorTitulo(String titulo){
		String retorno = "    ******* BUSCA DE M�DIA POR T�TULO ******    ";
		for (int i=0; i<m�dias.size(); i++){
			if (titulo.equals(m�dias.get(i).getT�tulo())){
				retorno = retorno +"\n"+ m�dias.get(i).imprimeFicha();
			}
		}
		return retorno;
	}
	
	//Retorna o array da cole��o para o m�todo imprimeCole��o
	public M�dia retornaM�dia(int i){
		return m�dias.get(i);
		
	}
	
	//Retorna o array da cole��o por tipo de m�dia para o m�todo imprimeCole��oPorTipo
	public ArrayList<M�dia> cole��oPorTipo(int tipo){
		//declarando um array tempor�rio de m�dias para receber os registros
		return m�dias;
		
	}
	
	//M�todo para imprimir cole��o por tipo
	public String imprimeCole��oPorTipo(int tipo){
		String retorno = "";
		if (tipo == 1){
			retorno = "    ******* IMPRESS�O DA COLE��O DE CDs ******    \n";
		}
		if (tipo == 2){
			retorno = "    ******* IMPRESS�O DA COLE��O DE DVDs ******    \n";
		}
		if (tipo == 3){
			retorno = "    ******* IMPRESS�O DA COLE��O DE JOGOS ******    \n";
		}
		for (int i=0; i<m�dias.size(); i++){
			if (m�dias.get(i).getTipo()==tipo){
				retorno = retorno +"\n"+ m�dias.get(i).imprimeFicha();
			}
		}
		return retorno;
	}
	
	//M�todo principal
	public static void main(String[] args){
		//atributos locais
		JButton btnCadastraCD, btnCadastraDVD, btnCadastraJogo, btnImprimeColecao, btnImprimeColecaoTipo, btnBusca, btnSair;				
		//Solicitando o n�mero de registros para instanciar o objeto
		//quantidade = Integer.parseInt(JOptionPane.showInputDialog(" ENTRE COM O N�MERO M�XIMO DE REGISTROS: "));
		//Instanciando o objeto cat�logo
		final Cat�logo cat�logo = new Cat�logo();
		
		cat�logo.bd = new conectaBD();
		if(cat�logo.bd.conecta())
			System.out.println("Conectado ao banco de dados");
		else
			System.out.println("N�o foi poss�vel conectar ao banco");
		
		ResultSet rs = cat�logo.bd.ler("select * from midia");

		try {
			while(rs.next()){				
				if(rs.getInt("tipo") == 1){
					CD cd = new CD(rs.getString("titulo"),rs.getInt("ano"),rs.getString("info"));
					ResultSet rs2 = cat�logo.bd.ler("select * from lista where midia_id = "+rs.getInt("id"));
					while(rs2.next()){
						cd.adicionaFaixa(rs2.getString("info"),Integer.parseInt(rs2.getString("info2")));
					}
			    	    	cat�logo.adicionaM�dia(cd);
				}

				if(rs.getInt("tipo") == 2){
					DVD dvd = new DVD(rs.getString("titulo"),rs.getInt("ano"),rs.getString("info"));
					ResultSet rs2 = cat�logo.bd.ler("select * from lista where midia_id = "+rs.getInt("id"));
					while(rs2.next()){
						dvd.adicionaArtista(rs2.getString("info"),rs2.getString("info2"));
					}
			    	    	cat�logo.adicionaM�dia(dvd);
				}

				if(rs.getInt("tipo") == 3){
					Jogo jogo = new Jogo (rs.getString("titulo"),rs.getInt("ano"),rs.getString("info"));
			    	    	cat�logo.adicionaM�dia(jogo);
				}
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//Iniciando a interface gr�fica
		final JFrame principal = new JFrame();
        principal.setTitle("SISTEMA DE ACERVO DE M�DIAS");
        principal.setLayout(new GridLayout(10,5));
        principal.setDefaultCloseOperation(EXIT_ON_CLOSE);
        //Iniciando r�tulos da p�gina
        JLabel rotulo1 = new JLabel("SISTEMA DE ACERVO DE M�DIAS - Escolha uma op��o abaixo:",JLabel.CENTER);
        JLabel rotuloBranco = new JLabel(" ",JLabel.CENTER);
        rotuloQtdMidias = new JLabel("M�dias Cadastradas: "+String.valueOf(cat�logo.quantidadeM�ximaDeM�dias()),JLabel.CENTER);
                
        //BOT�O CADASTRA CD
        btnCadastraCD = new JButton("CD");
        btnCadastraCD.setLocation(100, 100);
        btnCadastraCD.setVisible(true);
        btnCadastraCD.setBounds(100, 100, 100, 30);
        btnCadastraCD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cat�logo.cadastraCD(cat�logo, principal);
				principal.setVisible(false);
			}
		}); 
        
        //BOT�O CADASTRA DVD
        btnCadastraDVD = new JButton("DVD");
        btnCadastraDVD.setLocation(100, 100);
        btnCadastraDVD.setVisible(true);
        btnCadastraDVD.setBounds(100, 100, 100, 30);
        btnCadastraDVD.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cat�logo.cadastraDVD(cat�logo, principal);
				principal.setVisible(false);	
			}
		});
        
        //BOT�O CADASTRA JOGO
        btnCadastraJogo = new JButton("Jogo");
        btnCadastraJogo.setLocation(100, 100);
        btnCadastraJogo.setVisible(true);
        btnCadastraJogo.setBounds(100, 100, 100, 30);
        btnCadastraJogo.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cat�logo.cadastraJogo(cat�logo, principal);
				principal.setVisible(false);	
			}
		});
        
        //BOT�O IMPRIME COLE��O
        btnImprimeColecao = new JButton("Imprimir Cole��o");
        btnImprimeColecao.setLocation(100, 100);
        btnImprimeColecao.setVisible(true);
        btnImprimeColecao.setBounds(100, 100, 100, 30);
        btnImprimeColecao.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cat�logo.imprimeColecao(cat�logo, principal);
				principal.setVisible(false);	
			}
		});
        
        //BOT�O IMPRIME COLE��O POR TIPO
        btnImprimeColecaoTipo = new JButton("Imprimir Cole��o por tipo");
        btnImprimeColecaoTipo.setLocation(100, 100);
        btnImprimeColecaoTipo.setVisible(true);
        btnImprimeColecaoTipo.setBounds(100, 100, 100, 30);
        btnImprimeColecaoTipo.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cat�logo.imprimeColecaoTipo(cat�logo, principal);
				principal.setVisible(false);	
			}
		});
        
        //BOT�O BUSCA
        btnBusca = new JButton("Buscar Registro por Titulo");
        btnBusca.setLocation(100, 100);
        btnBusca.setVisible(true);
        btnBusca.setBounds(100, 100, 100, 30);
        btnBusca.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				cat�logo.buscaPorTitulo(cat�logo, principal);
				principal.setVisible(false);	
			}
		});
        
        //BOT�O SAIR
        btnSair = new JButton("SAIR DO PROGRAMA");
        btnSair.setLocation(100, 100);
        btnSair.setVisible(true);
        btnSair.setBounds(100, 100, 100, 30);
        btnSair.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					cat�logo.bd.fechar();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(0);	
			}
		});
        
        //Mostrando a tela principal
        principal.add(rotulo1);
        principal.add(btnCadastraCD);
        principal.add(btnCadastraDVD);
        principal.add(btnCadastraJogo);
        principal.add(btnImprimeColecao);
        principal.add(btnImprimeColecaoTipo);
        principal.add(btnBusca);
        principal.add(rotuloBranco);
        principal.add(rotuloQtdMidias);
        principal.add(rotuloBranco);
        principal.add(btnSair);
        principal.pack();
        principal.setSize(800, 600);
        principal.setResizable(false);
        principal.setLocationByPlatform(true);
        principal.setVisible(true);		
	}
}
