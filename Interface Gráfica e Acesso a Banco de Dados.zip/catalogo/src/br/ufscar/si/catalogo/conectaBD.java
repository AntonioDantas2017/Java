//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;

//Importanto bibliotecas necess�rias para a conex�o
import java.sql.*;

public class conectaBD {
	 //DEFINI��ES DO DRIVER JDBC E BASE MYSQL
	 static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	 static final String DB_URL = "jdbc:mysql://127.0.0.1/catalogo";
	
	 //CREDENCIAIS DE ACESSO DO BANCO DE DADOS
	 static final String USER = "root";
	 static final String PASS = "";
	 
	 //VARI�VEIS LOCAIS DA CLASSE
	 static Connection conn;
	 
	 //M�todo para retornar o resultado de uma conex�o com o banco de dados
	 public boolean conecta(){
		 try{
			    // REGISTRANDO O DRIVER JDBC
			    Class.forName("com.mysql.jdbc.Driver");
	
			    // ABBRINDO A CONEX�O
			    conn = DriverManager.getConnection(DB_URL,USER,PASS);
			    
			    // SUCESSO
			    return true;
			 }catch(Exception e){
			    // GERENCIANDO ERROS DA Class.forName
			    e.printStackTrace();
			    return false;
			 }
		}
	 
	 	//M�todo para retornar o resultado de uma busca a partir de uma instru��o sql
	 	public ResultSet ler(String sql){
	 		try{
			    // EXECUTANDO A QUERY SQL
			    Statement stmt = conn.createStatement();
			    ResultSet rs = stmt.executeQuery(sql);			    
			    // RETORNA DADOS
			    return rs;			    
			}catch(SQLException se){
			    // GERENCIANDO ERROS DO JDBC
			    se.printStackTrace();
			    return null;
	 		}
	 	}
	 
	 	//M�todo para realizar uma a��o no banco de dados a partir de uma instru��o sql
	 	public void modificar(String sql){
	 		try{
			    // EXECUTANDO A QUERY SQL
			    Statement stmt = conn.createStatement();
			    stmt.execute(sql);
			}catch(SQLException se){
			    // GERENCIANDO ERROS DO JDBC
			    se.printStackTrace();
	 		}
	 	}
	 
	 	//M�todo para fecjar a conex�o
	 	public void fechar() throws SQLException{
	 		conn.close();
	 	}
	 
 }