//UFSCar - Sead = Programa��o Orientada a Objetos 2
//Exerc�cio-Programa AA4-1 - Quarto Exerc�cio-programa em Java
//Andr� Luis Tardelli Magalh�es - RA 309966
//Antonio Josivaldo Dantas Filho - RA 580961

package br.ufscar.si.catalogo;

//Importando pacotes necess�rios
import java.util.Collection;

//Declara��o da Interface Cole��oM�dia e criando os m�todos necess�rios
public interface Cole��oM�dia {
	Collection<M�dia> cole��o();
	Collection<M�dia> cole��oPorTipo(int tipo);
}
