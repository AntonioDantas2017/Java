/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA2-1
 */

package br.ufscar.si.catalogo;

public class Jogo extends M�dia{

	//Atributos da classe
	private String g�nero;
	
	//Construtor da classe utilizando heran�a
	public Jogo(String t�tulo, int anoCria��o, String g�nero){
		super(t�tulo,anoCria��o);
		this.g�nero = g�nero;
	}

	//Construtor sem par�metros da classe
	public Jogo(){
		super("Sem T�tulo",0);
		this.g�nero = "Sem g�nero";
	}
	
	//Implementa��o do m�todo para retornar o tipo de m�dia
	@Override
	public int getTipo(){
		return 3;
	}
	
	//Implementa��o do m�todo para imprimir uma ficha com detalher da m�dia
	@Override
	public void imprimeFicha(){
		System.out.println("");
		System.out.println("T�tulo: "+this.getT�tulo());
		System.out.println("Ano: "+this.getAnoCria��o());
		System.out.println("Tipo: Jogo Eletr�nico");
		System.out.println("g�nero: "+this.g�nero);

	}
}
