/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA2-1
 */

package br.ufscar.si.catalogo;

//Classe de implementa��o para cat�logo de m�dias
public class Cat�logo implements Cole��oM�dia {

	//Array catalogo de m�dias
	private M�dia[] catalogo;
	//Variavel auxiliar para controle de inser��o
	private int controle_qtd;
	
	//Construtor da Classe com tamanho do cat�logo
	public Cat�logo(int tamMax){
		if(tamMax <= 300){
			this.catalogo = new M�dia[tamMax];
			this.controle_qtd =  0;
		}else{
			System.out.println("Tamanho n�o permitido");
			System.runFinalization();	
		}
		
	}
	
	//M�todo para adicionar uma nova m�dia
	public boolean adicionaM�dia(M�dia m�dia){
		try{//Tratamento de excess�o
			this.catalogo[this.controle_qtd] = m�dia;
			this.controle_qtd++;
			return true;
		}catch(ArrayIndexOutOfBoundsException e){
			return false;
		}
	}
	
	//M�todo para retornar uma m�dia a partir do t�tulo como par�metro
	public M�dia obtemM�dia(String t�tulo){
		if(controle_qtd==0) return null;
		
		for(int i=0;i<this.controle_qtd;i++){
			if(this.catalogo[i].getT�tulo().equals(t�tulo))
				return this.catalogo[i]; 
		}
		return null; //N�o encontrado
	}
	
	//M�todo para retornar o n�mero m�ximo de m�dias
	public int quantidadeM�ximaDeM�dias(){
		return this.catalogo.length;
	}
	
	//M�todo para informar a quantidade de m�dias cadastradas
	public int quantidadeDeM�dias(){
		return this.controle_qtd;
	}
	
	private int quantidade(M�dia m[], int tipo){
		int contador = 0;
		for(int i=0;i<this.controle_qtd;i++){
			if(this.catalogo[i].getTipo() == tipo)
				contador++;
		}
		return contador;
	}
	
	//M�todo para retornar a quantidade de CDs cadastrados
	public int quantidadeDeCDs(){
		return quantidade(this.catalogo,1);
	}
	
	//M�todo para retornar a quantidade de DVDs cadastrados
	public int quantidadeDeDVDs(){
		return quantidade(this.catalogo,2);
	}
	
	//M�todo para retornar a quantidade de CDs cadastrados
	public int quantidadeDeJogos(){
		return quantidade(this.catalogo,3);
	}
	
	//M�todo para retornar a cole��o completa de m�dias
	public M�dia[] cole��o(){
		return this.catalogo;
	}
	
	//M�todo para imprimir a cole��o completa
	public void imprimeCole��o(){
		for(int i=0;i<this.controle_qtd;i++)
			this.catalogo[i].imprimeFicha(); 
	}
	
	//M�todo para retornar a cole��o seleciona por tipo
	public M�dia[] cole��oPorTipo(int tipo){ 
		int controle_qtd2 = 0;
		for(int i=0;i<this.controle_qtd;i++){
			if(this.catalogo[i].getTipo() == tipo)
				controle_qtd2++; //contagem
		}
		
		M�dia[] novaM�dia = new M�dia[controle_qtd2];
		controle_qtd2 = 0;
		for(int i=0;i<this.controle_qtd;i++){
			if(this.catalogo[i].getTipo() == tipo){
				novaM�dia[controle_qtd2] = this.catalogo[i]; //inser��o 
				controle_qtd2++;
			}
		}
		return novaM�dia;
	}
	
	//M�todo para imprimir uma cole��o por tipo
	public void imprimeCole��oPorTipo(int tipo){
		for(int i=0;i<this.controle_qtd;i++){
			if(this.catalogo[i].getTipo() == tipo)
				this.catalogo[i].imprimeFicha();
		}
	}
	
	//M�todo para remover uma m�dia a partir do t�tulo como par�metro
	public void removeM�dia(String t�tulo){
		if(controle_qtd!=0){
			for(int i=0;i<this.controle_qtd;i++){
				if(this.catalogo[i].getT�tulo().equals(t�tulo)){
					this.catalogo[i] = this.catalogo[this.controle_qtd-1];
					this.catalogo[this.controle_qtd-1] = null;
					i=this.controle_qtd;
				}
					 
			}
		}
	}
	
}
