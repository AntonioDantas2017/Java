/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA2-1
 */

package br.ufscar.si.catalogo;

//Classe abstrata para controle de m�dias
public abstract class M�dia {

	//Atributos comuns da classe
	private String t�tulo;
	private int anoCria��o;
	
	//Construtor da classe
	public M�dia(String t�tulo, int anoCria��o){
		this.t�tulo = t�tulo;
		this.anoCria��o = anoCria��o;
	}
	
	//M�todo para retornar o t�tulo 
	public String getT�tulo(){
		return this.t�tulo;
	}
	
	//M�todo para retornar o ano de cria��o
	public int getAnoCria��o(){
		return this.anoCria��o;
	}
	
	//Construtor sem parametros da clasee
	public M�dia(){};
	
	//M�todos abstratos para implementa��o
	public abstract int getTipo();
	public abstract void imprimeFicha();
	
}
