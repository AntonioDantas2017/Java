/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA2-1
 */

package br.ufscar.si.catalogo;

//Classe do tipo interface para m�todos de cole��o de m�dias
public interface Cole��oM�dia {

	M�dia[] cole��o();
	M�dia[] cole��oPorTipo(int tipo);
	
}
