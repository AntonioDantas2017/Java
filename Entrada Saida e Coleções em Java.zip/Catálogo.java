/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */

package br.ufscar.si.catalogo;

import java.util.*;
import java.io.*;

//Classe de implementa��o para cat�logo de m�dias
public class Cat�logo implements Cole��oM�dia, Serializable {
	
	private static final long serialVersionUID = 1L;
	
	//Array catalogo de m�dias
	private Collection<M�dia> catalogo;
	private int maximo;
	
	//Construtor da Classe com tamanho do cat�logo do tipo ArrayList 
	public Cat�logo(int tamMax){
		if(tamMax <= 300){
			this.catalogo = new ArrayList<M�dia>(tamMax);
			this.maximo = tamMax;
		}else{
			System.out.println("Tamanho n�o permitido");
			System.runFinalization();	
		}
		
	}
	
	//M�todo para adicionar uma nova m�dia
	public boolean adicionaM�dia(M�dia m�dia){
		try{//Tratamento de excess�o
			if(catalogo.size() >= maximo)
				return false;
			else{
				catalogo.add(m�dia);
				return true;
			}
		}catch(Exception e){
			return false;
		}
	}
	
	//M�todo para retornar uma m�dia a partir do t�tulo como par�metro
	public M�dia obtemM�dia(String t�tulo){
		for(M�dia m1 : catalogo){
			if(m1.getT�tulo().equals(t�tulo))
				return m1; 
		}
		return null; //N�o encontrado
	}
	
	//M�todo para retornar o n�mero m�ximo de m�dias
	public int quantidadeM�ximaDeM�dias(){
		return this.maximo;
	}
	
	//M�todo para informar a quantidade de m�dias cadastradas
	public int quantidadeDeM�dias(){
		return catalogo.size();
	}
	
	//M�todo para informar a quantidade de m�dias por tipo
	private int quantidade(Collection<M�dia> catalogo2, int tipo){
		int contador = 0;
		for(M�dia m : catalogo2){
			if(m.getTipo() == tipo)
				contador++;
		}
		return contador;
	}
	
	//M�todo para retornar a quantidade de CDs cadastrados
	public int quantidadeDeCDs(){
		return quantidade(this.catalogo,1);
	}
	
	//M�todo para retornar a quantidade de DVDs cadastrados
	public int quantidadeDeDVDs(){
		return quantidade(this.catalogo,2);
	}
	
	//M�todo para retornar a quantidade de CDs cadastrados
	public int quantidadeDeJogos(){
		return quantidade(this.catalogo,3);
	}
	
	//M�todo para retornar a cole��o completa de m�dias
	public Collection<M�dia> cole��o(){
		TituloComparator comparator = new TituloComparator();
		Collections.sort((List<M�dia>) catalogo, comparator);
		return this.catalogo;
	}
	
	//M�todo para imprimir a cole��o completa
	public void imprimeCole��o(){
		for(M�dia m : catalogo)
			m.imprimeFicha(); 
	}
	
	//M�todo para retornar a cole��o seleciona por tipo
	public Collection<M�dia> cole��oPorTipo(int tipo){ 
		Collection<M�dia> novaCole��o = new ArrayList<M�dia>();
		for(M�dia m1 : catalogo){
			if(m1.getTipo() == tipo){
				novaCole��o.add(m1); //inser��o 
			}
		}
		
		return novaCole��o;
	}
	
	//M�todo para imprimir uma cole��o por tipo
	public void imprimeCole��oPorTipo(int tipo){
		for(M�dia m : catalogo){
			if(m.getTipo() == tipo)
				m.imprimeFicha();
		}
	}
	
	//M�todo para remover uma m�dia a partir do t�tulo como par�metro
	public void removeM�dia(String t�tulo){
		for(M�dia m : catalogo){
			if(m.getT�tulo().equals(t�tulo))
				catalogo.remove(m);
		}
	}
	
	//M�todo que recebe dois arquivos e um �ndice para realizar a descriptografa��o
	public void encripte(String fileIn, String fileOut, int k) throws IOException{
		try {
			//Abertura de arquivo texto para leitura
			BufferedReader IN = new BufferedReader(new FileReader(fileIn));
			//Abertura de arquivo texto para escrita
			BufferedWriter OUT = new BufferedWriter(new FileWriter(fileOut));
			
			//VAri�veis auxiliares
			String linha = "";
			int c = 0;
			int i = 0;
			
			while(true){
				linha = IN.readLine(); //Leitura de uma linha do arquivo
				if(linha != null){
					for(i=0;i<linha.length();i++){
						c = (int)linha.charAt(i);
						OUT.write((char)c+k); //Escrita no arquivo
					}
					OUT.newLine(); //Nova linha no arquivo
				}else
					break; //Arquivo finalizado
			}
			OUT.close(); //Fechamento do arquivo
			IN.close(); //Fechamento do arquivo
		} catch (FileNotFoundException e) {
			System.out.println("N�o foi poss�vel abrir o arquivo, favor criar na pasta de workspace");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
