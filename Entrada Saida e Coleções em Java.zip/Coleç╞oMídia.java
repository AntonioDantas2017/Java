/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */
package br.ufscar.si.catalogo;

import java.util.*;

//Classe do tipo interface para m�todos de cole��o de m�dias
public interface Cole��oM�dia {

	Collection<M�dia> cole��o();
	Collection<M�dia> cole��oPorTipo(int tipo);
	
}
