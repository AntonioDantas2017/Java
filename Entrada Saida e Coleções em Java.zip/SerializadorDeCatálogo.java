/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */

package br.ufscar.si.catalogo;

import java.io.*;

//Classe para realizar a serializa��o da classe cat�logo
public class SerializadorDeCat�logo {

	//M�todo para escrever uma arquivo serializado do tipo cat�logo
	public void gravaCat�logo (Cat�logo c, String f){
		try{
			File file = new File(f);
			FileOutputStream fos = new FileOutputStream(file); //Cria��o do arquivo
			ObjectOutputStream saida = new ObjectOutputStream(fos); //Vincula��o do arquivo
			saida.writeObject(c); //Escrita do objeto no arquivo
			saida.close(); //Fechamento do arquivo
		}catch(IOException e){
			  e.printStackTrace();
			  System.out.println("Erros durante os testes !!");
		}
	}
	
	//M�todo para ler um arquivo serizalizado e carregar em um objeto tipo Cat�logo
	public Cat�logo carregaCat�logo(String f) throws IOException, ClassNotFoundException{
		File file = new File(f);
		ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(file)); //Vincula��o do arquivo
		Cat�logo c = (Cat�logo) entrada.readObject(); //Leitura do arquivo
		entrada.close(); //Fechamento do arquivo
		return c; //Retorno da fun��o com o Cat�logo carregado
	}
	
}
