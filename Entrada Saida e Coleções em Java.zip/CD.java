/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */

package br.ufscar.si.catalogo;

public class CD extends M�dia{
	
	//Atributos da classe
	private String artista;
	private String[] faixas;
	private int[] dura��o;
	private int controle;
	
	//Construtor da classe utilizando heran�a
	public CD(String t�tulo, int anoCria��o, String artista){
		super(t�tulo,anoCria��o);
		this.artista = artista;
		faixas = new String[15];
		dura��o = new int[15];
		this.controle = 0;
	}

	//Construtor sem par�metros da classe
	public CD(){
		super("Sem T�tulo",0);
		this.artista = "Sem Artista";
		faixas = new String[15];
		dura��o = new int[15];
		this.controle = 0;
	}

	//M�todo para adicionar artistas para a m�dia
	public void adicionaFaixa(String faixa, int dura��o){
		this.faixas[controle] = faixa;
		this.dura��o[controle] = dura��o;
		this.controle++;
	}
	
	//Implementa��o do m�todo para retornar o tipo de m�dia
	@Override
	public int getTipo(){
		return 1;
	}
	
	//Implementa��o do m�todo para imprimir uma ficha com detalhes da m�dia
	@Override
	public void imprimeFicha(){																	
		System.out.println("");
		System.out.println("T�tulo: "+this.getT�tulo());
		System.out.println("Ano: "+this.getAnoCria��o());
		System.out.println("Tipo: CD de m�sica");
		System.out.println("Artista: "+this.artista);
		
		for(int i=0; i<controle;i++)
			System.out.println("Faixa "+(i+1)+": "+this.faixas[i]+", dura��o: "+this.dura��o[i]);
	}
}
