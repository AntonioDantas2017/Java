package br.ufscar.si.catalogo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class TestaCatálogo {

    private static CD cd1, cd2;
    private static DVD dvd1, dvd2;
    private static Jogo jogo1, jogo2;

    private static boolean ehIgual(Collection<Mídia> a, Collection<Mídia> b) {
        boolean ehIgual = a.size() == b.size();

        Iterator<Mídia> itA = a.iterator();
        Iterator<Mídia> itB = b.iterator();

        for (int i = 0; itA.hasNext() && ehIgual; i++) {
            ehIgual = itA.next().equals(itB.next());
        }
        return ehIgual;
    }

    private static void testaRecuperação(Catálogo catálogo) {

        Collection<Mídia> coleção;

        assert (catálogo.obtemMídia("Fifa 2008").equals(jogo2));
        assert (catálogo.obtemMídia("Matrix").equals(dvd2));
        assert (catálogo.obtemMídia("X & Y").equals(cd1));
        assert (catálogo.obtemMídia("Need For Speed - Underground II").equals(jogo1));
        assert (catálogo.obtemMídia("O Senhor dos Anéis - A Sociedade dos Anel").equals(dvd1));
        assert (catálogo.obtemMídia("Bachianas Brasileiras No.2").equals(cd2));

        // Catálogo cheio
        assert (catálogo.adicionaMídia(jogo2) == false);

        // Verificando lista (todos)

        assert (catálogo.quantidadeDeMídias() == 6);

        assert (catálogo.quantidadeDeMídias() == catálogo.quantidadeMáximaDeMídias());

        coleção = new ArrayList<Mídia>();
        coleção.add(dvd2);
        coleção.add(dvd1);
        coleção.add(cd2);
        coleção.add(jogo1);
        coleção.add(cd1);
        coleção.add(jogo2);

        assert (ehIgual(catálogo.coleção(), coleção));

        // Verificando lista (seleciona pelo tipo - CD de música - implementada
        // pela classe CD)

        assert (catálogo.quantidadeDeCDs() == 2);

        coleção = new ArrayList<Mídia>();
        coleção.add(cd2);
        coleção.add(cd1);

        assert (ehIgual(catálogo.coleçãoPorTipo(1), coleção));

        // Verificando lista (seleciona pelo tipo - DVD de filme - implementada
        // pela classe DVD)

        assert (catálogo.quantidadeDeDVDs() == 2);

        coleção = new ArrayList<Mídia>();
        coleção.add(dvd2);
        coleção.add(dvd1);

        assert (ehIgual(catálogo.coleçãoPorTipo(2), coleção));

        // Verificando lista (seleciona pelo tipo - Jogo Eletrônico -
        // implementada pela classe Jogo)

        assert (catálogo.quantidadeDeJogos() == 2);

        coleção = new ArrayList<Mídia>();
        coleção.add(jogo1);
        coleção.add(jogo2);

        assert (ehIgual(catálogo.coleçãoPorTipo(3), coleção));
    }

    public static void inicializaVariáveis() {
        cd1 = new CD("X & Y", 2005, "Cold Play");
        cd1.adicionaFaixa("Square One", 287); // 4:47
        cd1.adicionaFaixa("What If", 297); // 4:57
        cd1.adicionaFaixa("White Shadows", 328); // 5:28
        cd1.adicionaFaixa("Fix You", 294); // 4:54
        cd1.adicionaFaixa("Talk", 311); // 5:11
        cd1.adicionaFaixa("X&Y", 274); // 4:34

        dvd1 = new DVD("O Senhor dos Anéis - A Sociedade dos Anel", 2001,
                "Peter Jacson");
        dvd1.adicionaArtista("Elijah Wood", "Frodo Baggins");
        dvd1.adicionaArtista("Viggo Mortensen", "Aragorn");
        dvd1.adicionaArtista("Orlando Bloom", "Legolas Greenleaf");
        dvd1.adicionaArtista("Christopher Lee", "Saruman");
        dvd1.adicionaArtista("Ian McKellen", "Gandalf");

        jogo1 = new Jogo("Need For Speed - Underground II", 2005, "Corrida");

        cd2 = new CD("Bachianas Brasileiras No.2", 2004,
                "Orquestra de Câmara da Universidade de São Paulo");
        cd2.adicionaFaixa("(Prelúdio) O Canto do Capadócio", 512); // 4:32
        cd2.adicionaFaixa("(Ária) O Canto da Nossa Terra", 389); // 6:29
        cd2.adicionaFaixa("(Dança) Lembranca do Sertão", 324); // 5:24
        cd2.adicionaFaixa("(Tocata) O Trenzinho do Caipira", 284); // 4:44

        dvd2 = new DVD("Matrix", 1999, "Andy & Larry Wachoski");
        dvd2.adicionaArtista("Keanu Reeves", "Neo");
        dvd2.adicionaArtista("Laurence Fishburne", "Morpheus");
        dvd2.adicionaArtista("Carrie-Anne Moss", "Trinity");
        dvd2.adicionaArtista("Hugo Weaving", "Agente Smith");
        dvd2.adicionaArtista("Gloria Foster", "Óraculo");

        jogo2 = new Jogo("Fifa 2008", 2008, "Esporte");
    }

    public static void realizaTestes() {

        inicializaVariáveis();

        /**
         * Testa se o assert está habilitado. No Java o assert não é habilitado
         * por padrão.
         *
         * Para executar inclua a opção -ea
         *
         * Exemplo: java -ea TestaCatálogo
         */
        int a = 0;
        assert (a++ == 0);
        if (a == 0) {
            System.out.println("Assertions desabilitados. O programa não foi testado!");
            System.exit(-1);
        }

        // Criar uma classe cadastro e tenta buscar uma midia na lista vazia
        Catálogo catálogo = new Catálogo(6);

        assert (catálogo.obtemMídia("Senhor dos Aneis") == null);

        // adiciona 6 midias

        assert (catálogo.adicionaMídia(cd1));
        assert (catálogo.adicionaMídia(dvd1));
        assert (catálogo.adicionaMídia(jogo1));
        assert (catálogo.adicionaMídia(cd2));
        assert (catálogo.adicionaMídia(dvd2));
        assert (catálogo.adicionaMídia(jogo2));

        // Tenta recuperar cadastros

        testaRecuperação(catálogo);

        SerializadorDeCatálogo s = new SerializadorDeCatálogo();
        s.gravaCatálogo(catálogo, "teste.dat");

        System.out.println("Testes executados com sucesso !!");
    }

    public static void main(String[] args) {
        try {
            if (args.length == 1) {
                SerializadorDeCatálogo s = new SerializadorDeCatálogo();
                Catálogo catalogo = s.carregaCatálogo("teste.dat");
                inicializaVariáveis();
                testaRecuperação(catalogo);
            } else {
                realizaTestes();
            }
        } catch (AssertionError e) {
            e.printStackTrace();
            System.out.println("Erros durante os testes !!");
        }
    }
}
