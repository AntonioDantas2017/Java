/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */

package br.ufscar.si.catalogo;

import java.util.*;

//Classe �ra implementar Comparador de m�dias por t�tulo
public class TituloComparator implements Comparator<M�dia> {
	public int compare(M�dia m, M�dia m1) {
        return m.getT�tulo().
                compareTo(m1.getT�tulo());
    }
}
