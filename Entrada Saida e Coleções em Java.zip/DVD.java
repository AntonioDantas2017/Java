/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */

package br.ufscar.si.catalogo;

public class DVD extends M�dia{

	//Atributos da classe
	private String diretor;
	private String[] artistas;
	private String[] papel;
	private int controle;
	
	//Construtor da classe utilizando heran�a
	public DVD(String t�tulo, int anoCria��o, String diretor){
		super(t�tulo,anoCria��o);
		this.diretor = diretor;
		artistas = new String[5];
		papel = new String[5];
		this.controle = 0;
	}
	
	//Construtor sem par�metros da classe
	public DVD(){
		super("Sem T�tulo",0);
		this.diretor = "Sem diretor";
		artistas = new String[5];
		papel = new String[5];
		this.controle = 0;
	}
	
	//M�todo para adicionar artistas para a m�dia 
	public void adicionaArtista(String artista, String papel){
		this.artistas[controle] = artista;
		this.papel[controle] = papel;
		this.controle++;
	}
	
	//Implementa��o do m�todo para retornar o tipo de m�dia
	@Override
	public int getTipo(){
		return 2;
	}
	
	//Implementa��o do m�todo para imprimir uma ficha com detalher da m�dia
	@Override
	public void imprimeFicha(){
		System.out.println("");
		System.out.println("T�tulo: "+this.getT�tulo());
		System.out.println("Ano: "+this.getAnoCria��o());
		System.out.println("Tipo: Filme em DVD");
		System.out.println("diretor: "+this.diretor);
		
		for(int i=0; i<controle;i++)
			System.out.println("Artista "+(i+1)+": "+this.artistas[i]+", papel: "+this.papel[i]);
	}

	
}
