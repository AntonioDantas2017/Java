/*
 * Antonio Josivaldo Dantas Filho
 * RA 580961 - Sistemas de Informa��o - G7 - UAB SJC - Ufscar 
 * Atividade AA3-1
 */

package br.ufscar.si.catalogo;

import java.io.*;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

//Classe abstrata para controle de m�dias e implementa��o Serializable e compara��o de m�dias
public abstract class M�dia extends TestaCat�logo implements Comparable<M�dia>,Serializable{
		
	private static final long serialVersionUID = 1L;
	
	//Atributos comuns da classe
	private String t�tulo;
	private int anoCria��o;
	
	//Compara��o por ano de cria��o
	public int compareTo (M�dia m) {
        if (this.anoCria��o < m.anoCria��o) {
            return -1;
        }
        if (this.anoCria��o > m.anoCria��o) {
            return 1;
        }
        return 0;
	}
	
	//Construtor da classe
	public M�dia(String t�tulo, int anoCria��o){
		this.t�tulo = t�tulo;
		this.anoCria��o = anoCria��o;
	}
	
	//M�todo para retornar o t�tulo 
	public String getT�tulo(){
		return this.t�tulo;
	}
	
	//M�todo para retornar o ano de cria��o
	public int getAnoCria��o(){
		return this.anoCria��o;
	}
	
	//Sobrescreve hasCode
	@Override
	public int hashCode() {
	    return 0;
	}
	
	//Sobrescrever equals para compara��o de m�dias
	@Override
	public boolean equals(Object object){
		return (object instanceof M�dia) && (((M�dia)object).getT�tulo().equals(this.getT�tulo()));  
	}
	
	//Construtor sem parametros da clasee
	public M�dia(){};
	
	//M�todos abstratos para implementa��o
	public abstract int getTipo();
	public abstract void imprimeFicha();
	
	
}
